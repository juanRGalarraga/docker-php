<?php
/*
	Esto es para hacer test sobre la clase DBUtil 3.0
	Created: 2021-08-14
	Author: DriverOp
*/

define("DBHOST","localhost");
define("DBNAME","rbt_200");
define("DBUSER","root");
define("DBPASS","");
define("DBPORT", 3306);


const TBL_depruebas = 'tabla_de_pruebas';

require_once("..\initialize.php");
require_once(DIR_includes."controlErrors.inc.php");
require_once(DIR_includes."common.inc.php");


require_once(DIR_model."depruebas".DS."class.depruebas.inc.php");


$depruebas = new cDepruebas();

/* Obtener un registro 
if (!$depruebas->Get(1)) {
	EchoLog('Registro 1 no encontrado');
	exit;
}
EchoLog('Nombre: '.$depruebas->nombre);
EchoLog('Monto valor original: '.$depruebas->monto);
EchoLog('   Monto como moneda: '.$depruebas->cur_monto);

exit;
 */

/* Modificar un registro existente 
if (!$depruebas->Get(2)) {
	EchoLog('Registro 2 no encontrado');
	exit;
}
$depruebas->nombre = 'Ahora tiene nombre';
$depruebas->monto = rand(1000,10000)/3;
$depruebas->data->modificado = 'Yes!';
$depruebas->Set();
exit;
 */

/* Insertar un registro, desde las propiedades 

$depruebas->monto = rand(1000,2000)/3;
$depruebas->nombre = 'Insertado desde propiedades';
$depruebas->relleno = rand(100,999);

$un_objeto = new stdClass();
$un_objeto->unapropiedad = 'Para pruebas';

$depruebas->data = $un_objeto;

$depruebas->New();
exit;
 */

/* Insertar un registro, desde array */

$un_objeto = new stdClass();
$un_objeto->una_propiedad = sha1(date('Y-m-d His'));

$record = array(
	'nombre'=>'El nombre es '.md5(date('Y-m-d His')),
	'monto'=>rand(99,10000)/7,
	'relleno'=>rand(1,1000),
	'data'=>$un_objeto
);

$depruebas->NewRecord($record);

/* */